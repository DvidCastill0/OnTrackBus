package com.example.notificaciones;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button  btNotificacion;
    private PendingIntent pendingIntent;
    private PendingIntent siPendingIntent;
    private PendingIntent noPendingIntent;
    private final static String CHANNEL_ID="NOTIFICACION";
    private final static int NOTIFICACION_ID=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btNotificacion = findViewById(R.id.btNotificacion);
        btNotificacion.setOnClickListener(new View.OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view){

                setPendingIntent();
                createNotificationChannel();
                createNotification();



            }
        });
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void setSiPendingIntent(){
        Intent intent=new Intent(this,SiActivity.class);
        TaskStackBuilder stackBuilder=TaskStackBuilder.create(this);
        stackBuilder.addParentStack(SiActivity.class);
        stackBuilder.addNextIntent(intent);
        //Mencionarlo en el manifest de la aplicacion si no vale cagada las ultimas 5 lineas de codigo
        siPendingIntent=stackBuilder.getPendingIntent(1,pendingIntent.FLAG_UPDATE_CURRENT);


    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void setNoPendingIntent(){
        Intent intent=new Intent(this,NoActivity.class);
        TaskStackBuilder stackBuilder=TaskStackBuilder.create(this);
        stackBuilder.addParentStack(NoActivity.class);
        stackBuilder.addNextIntent(intent);
        //Mencionarlo en el manifest de la aplicacion si no vale cagada las ultimas 5 lineas de codigo
        noPendingIntent=stackBuilder.getPendingIntent(1,pendingIntent.FLAG_UPDATE_CURRENT);


    }
    //Mandar a una actividad dentro de la aplicacion
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void setPendingIntent(){
        Intent intent=new Intent(this,MainActivity.class);
        TaskStackBuilder stackBuilder=TaskStackBuilder.create(this);
        stackBuilder.addParentStack(MainActivity.class);
        stackBuilder.addNextIntent(intent);
        //Mencionarlo en el manifest de la aplicacion si no vale cagada las ultimas 5 lineas de codigo
        pendingIntent=stackBuilder.getPendingIntent(1,pendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);

    }
    //Creacion de Canales para Android Oreo a superiores
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createNotificationChannel(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.0){
            CharSequence name = "Notificacion";
            NotificationChannel notificationChannel=new NotificationChannel(CHANNEL_ID,name, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);

        }
    }

    //Versiones anteriores a Android Oreo
    private void createNotification(){
        NotificationCompat.Builder builder=new NotificationCompat.Builder(getApplicationContext(),CHANNEL_ID);
        builder.setSmallIcon(R.drawable.ic_directions_bus_black_24dp);
        builder.setContentTitle("Notificaciones Personalizadas");
        builder.setContentText("Te has subido ya a tu ruta seleccionada");
        builder.setColor(Color.BLUE);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setLights(Color.MAGENTA,1000,1000);
        builder.setVibrate(new long []{1000,1000,1000,1000,1000});
        builder.setDefaults(Notification.DEFAULT_SOUND);

        builder.setContentIntent(pendingIntent);
        builder.addAction(R.drawable.ic_directions_bus_black_24dp,"Si me subi a la ruta ",siPendingIntent);
        builder.addAction(R.drawable.ic_directions_bus_black_24dp,"No me he subido",noPendingIntent);



        NotificationManagerCompat notificationManagerCompat=NotificationManagerCompat.from(getApplicationContext());
        notificationManagerCompat.notify(NOTIFICACION_ID,builder.build());

    }


}
