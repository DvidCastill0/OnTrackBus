package com.example.interfazontrackbus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnotificaciones;
    NotificationCompat.Builder notificacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotificationCompat.Builder notificacion;
    }
    //metodo del boton para ir a mapa
    public void Siguiente(View view){
        Intent Siguiente=new Intent(this,MapsActivity.class);
        startActivity(Siguiente);
    }
    //metodo del boton para ir a Contactos
    public void Confianza(View view){
        Intent Confianza=new Intent(this,Contactos.class);
        startActivity(Confianza);
    }
    //metodo para cambiar a la interfaz de la actividad de la semana
    public void Actividad(View view){
        Intent Actividad=new Intent(this,Actividad_semana.class );
        startActivity(Actividad);
    }
    /*
    //Creacion de notificaciones
    private Button btnotificaciones;
    NotificationCompat.Builder notificacion;

    private static final int idUnico=17;
     btnotificaciones=(Button)FindViewbyId(R.id.btnotificaciones);
     notificacion = new NotificationCompat.Builder(this);
     notificacion.setAutoCancel(true);
     //Propiedades de las notificaciones
     btnotificaciones.setOnClickListener(new View.OnClickListener);
     */




    
}
