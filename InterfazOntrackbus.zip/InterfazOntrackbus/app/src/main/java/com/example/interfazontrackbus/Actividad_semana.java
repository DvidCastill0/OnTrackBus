package com.example.interfazontrackbus;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.interfazontrackbus.dummy.DummyContent;

import java.util.Date;

public class Actividad_semana extends AppCompatActivity implements View.OnClickListener,DateFragment.OnListFragmentInteractionListener {
    ImageButton imageButton;
    public Object DateFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_semana);
        imageButton=(ImageButton)findViewById(R.id.imageButton);
        imageButton.setOnClickListener(this);

    }
    @Override
    public void onClick(View view){
        DateFragment=new DateFragment();
        //Obtener la instancia del administrador de fragmentos
        FragmentManager fragmentManager=getFragmentManager();

        //Crear  una nueva transaccion
        FragmentTransaction transaction=fragmentManager.beginTransaction();

        //Crear un nuevo fragmento y añadirlo
       DateFragment =new DateFragment();
        transaction.add(R.id.content, (Fragment) DateFragment);

         //confirmar el cambio
        transaction.commit();

    }

    @Override
    public void onListFragmentInteraction(DummyContent.DummyItem item) {

    }

    //pasar cosas de comunicacion entre el activity y el fragment ejemplo:un resumen de la actividad diaria
    public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(DummyContent.DummyItem item);
    }
}
