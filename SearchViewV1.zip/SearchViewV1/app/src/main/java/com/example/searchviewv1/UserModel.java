package com.example.searchviewv1;

import java.io.Serializable;

public class UserModel implements Serializable {
    private String userRute;

    public UserModel(String userRute) {
        this.userRute = userRute;
    }

    public String getUserRute() {
        return userRute;
    }

    public void setUserRute(String userRute) {
        this.userRute = userRute;
    }
}
