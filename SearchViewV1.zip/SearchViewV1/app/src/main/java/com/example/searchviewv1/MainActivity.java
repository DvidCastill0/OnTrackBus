package com.example.searchviewv1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.UserManager;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements UserAdapter.SelectedUser {
    //Variables de firebase
    private DatabaseReference OTBreference;
    private int ContadorHijos=1;
    private Bundle NombreRutas=new Bundle();
    //Variables graficas de Mi buscador
    Toolbar toolbar;
    RecyclerView recyclerView;
    List<UserModel>userModelList=new ArrayList<>();
    //Declarar las rutas de camiones
    String[]rutes={"231-C","231","615-Voca","604-A","644-B","644-B sbz","647","51C","136-A","178"};
    UserAdapter userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //acceso a la base de datos
        OTBreference = FirebaseDatabase.getInstance().getReference();





        //Encontrar las vistas  de los elementos de la barra de busqueda
        recyclerView=findViewById(R.id.recyclerview);
        toolbar=findViewById(R.id.toolbar);

        this.setSupportActionBar(toolbar);
        this.getSupportActionBar().setTitle("");

        //Hacer la decoracion de los elementos de busqueda
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));



        for(String s:rutes){
            UserModel userModel=new UserModel(s);
            //Añadir a la lista elementos
            userModelList.add(userModel);
        }
        userAdapter=new UserAdapter(userModelList,this);

        recyclerView.setAdapter(userAdapter);



    }

    @Override
    public void selectedUser(UserModel userModel) {
        startActivity(new Intent(MainActivity.this,SelectedUserActivity.class).putExtra("data",userModel));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        //Inflar el menu
        getMenuInflater().inflate(R.menu.menu,menu);
        MenuItem menuItem = menu.findItem(R.id.search_view);
        //SearchView Barra de Busqueda interfaz menu

        SearchView searchView=(SearchView)menuItem.getActionView();
        searchView.setMaxWidth((Integer.MAX_VALUE));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                userAdapter.getFilter().filter(newText);
                return true;
            }
        });
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id ==R.id.search_view){
            return  true;
        }
        return  super.onOptionsItemSelected(item);

    }

}
