package com.example.searchviewv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;

public class popup extends AppCompatActivity {
    TextView tvUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);

        tvUser = findViewById(R.id.selectedUser);

        //Obtener las medidas de la ventana para el popup
        DisplayMetrics medidasVentana= new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(medidasVentana);

        //Creacion de variables para la obtencion de las medidas

        int ancho = medidasVentana.widthPixels;
        int alto = medidasVentana.heightPixels;

        getWindow().setLayout((int)(ancho*0.8),(int)(alto*0.5));

        Intent intent=getIntent();
        //Obtener la informacion de la ruta seleccionada del usuario

        if (intent.getExtras() !=null){
            UserModel userModel= (UserModel) intent.getSerializableExtra("data");
            tvUser.setText(userModel.getUserRute());
        }

    }
    //metodo del boton popup para regresar directamente del canal
    public void Canal(View view){
        Intent Siguiente=new Intent(this,SelectedUserActivity.class);
        startActivity(Siguiente);
    }
    //metodo del boton popup para regresar directamente del canal
    public void Siguiente(View view){
        Intent Siguiente=new Intent(this,MainActivity.class);
        startActivity(Siguiente);
    }
}
