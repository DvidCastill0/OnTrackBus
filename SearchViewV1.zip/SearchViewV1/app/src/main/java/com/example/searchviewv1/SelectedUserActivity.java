package com.example.searchviewv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SelectedUserActivity extends AppCompatActivity {
    TextView tvUser;
    private Button btnPopupCanal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //El usuario al seleccionar una ruta que es lo que se hara
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_user);
        tvUser = findViewById(R.id.selectedUser);
        //conectar nuestro boton para popup canales
        btnPopupCanal=findViewById(R.id.btnPopupCanales);


        //Crear la vista para Popup a traves de  un boton
        btnPopupCanal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SelectedUserActivity.this,popup.class));


            }
        });


        Intent intent=getIntent();
        //Obtener la informacion de la ruta seleccionada del usuario

        if (intent.getExtras() !=null){
            UserModel userModel= (UserModel) intent.getSerializableExtra("data");
            tvUser.setText(userModel.getUserRute());
        }


    }
}
